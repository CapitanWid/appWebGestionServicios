#!/bin/bash

# 1. OBTENER EL NOMBRE DEL ARCHIVO SIN LA EXTENSIÓN .sh
# Si el archivo se llama 'loguero.sh', NOMBRE será 'loguero'
NOMBRE="$(basename "$0" .sh)"

# 2. RUTA DINÁMICA (donde esté el script)
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ARCHIVO="${NOMBRE}.log"
RUTA="$DIR/$ARCHIVO"

touch "$RUTA"

while true; do
    ULTIMO=$(tail -n 1 "$RUTA" 2>/dev/null | cut -d '-' -f 1 | tr -d ' ')
    [[ "$ULTIMO" =~ ^[0-9]+$ ]] || ULTIMO=0

    NUEVO=$((ULTIMO + 1))
    FECHA=$(date "+%Y-%m-%d %H:%M:%S")
    LINEA="$NUEVO - $FECHA"

    # stdbuf asegura que Go reciba la línea al instante
    echo "$LINEA" | stdbuf -oL tee -a "$RUTA"
    
    sleep 2
done